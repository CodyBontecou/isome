# Whereday travel journal example

All coordinates, dates and visits are invented. This is a documentation example, not personal history.

1. Extract this ZIP to a new folder. Keep its folder layout unchanged.
2. In desktop Obsidian, use Open folder as vault and choose Whereday-travel-journal-example.
3. Open Trip reflections and switch to Reading view. Its source link should open Location/synthetic-obsidian-export, showing two visits on January 1, 2000.
4. For your own journal, copy the contents of Templates/Travel journal to a new note with a different filename. Fill in the date and timezone context. Replace its link instruction by selecting an actual exported note in your vault.
5. Keep handwritten notes separate from generated exports. Compare files before replacing any export.

The blank template is ordinary Markdown with manual fields. It does not require Templates, Daily notes, community plugins or a Whereday account. No plugins or vault settings are bundled. No sync or map is configured.

The source table is the unchanged earlier native synthetic export. Its Export Date is the creation date, not the visit date. Its clock times were generated in UTC. This example does not verify mobile transfer or scheduled exports. None of these notes replaces a supported backup.

Guide: https://whereday.com/blog/iphone-location-journal-obsidian/#journal-template
